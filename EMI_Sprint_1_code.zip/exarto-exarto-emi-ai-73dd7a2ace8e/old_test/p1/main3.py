import tensorflow as tf
import matplotlib.pyplot as plt
import numpy as np
import os
import cv2


def load_image():
    # img_name = "1425.jpg"
    # img_path = os.path.join(os.getcwd() + "/kagglecatsanddogs/Test_pets/Cat/", img_name)

    img_name = "2334.jpg"
    img_path = os.path.join(os.getcwd() + "/kagglecatsanddogs/Test_pets/Dog/", img_name)

    img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
    plt.figure()
    plt.imshow(img, cmap="gray")
    img = cv2.resize(img, (IMAGE_SIZE_WEIGHT, IMAGE_SIZE_HEIGHT))
    return img


def show_image(img):
    plt.figure()
    plt.imshow(img, cmap="gray")
    plt.show()


def create_test_data(img, test_data):
    test_data.append(img)
    test_data2 = np.array(test_data) ##
    print(test_data2.shape) ##(1,80,50)
    test_data = np.array(test_data).reshape(-1, IMAGE_SIZE_HEIGHT, IMAGE_SIZE_WEIGHT, 1)
    test_data = test_data/255.0
    print(" * Test_data: ", test_data)
    print(" * Test_data type: ", type(test_data))
    print(" * Test_data shape: ", test_data.shape)
    return test_data


def load_model():
    return tf.keras.models.load_model('cat_dog.model')


def predict(model, test_data):
    predictions = model.predict(test_data)
    print(" * Prediction: ", predictions)


if __name__ == "__main__":

    test_data = []
    Categories = ["Cat", "Dog"]
    IMAGE_SIZE_HEIGHT = 80
    IMAGE_SIZE_WEIGHT = 50

    img = load_image()
    show_image(img)
    test_data = create_test_data(img, test_data)
    model = load_model()
    predict(model, test_data)