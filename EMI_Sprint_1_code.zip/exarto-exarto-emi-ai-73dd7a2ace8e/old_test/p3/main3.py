import tensorflow as tf
import matplotlib.pyplot as plt
import numpy as np
import os
import cv2


def load_image():
    img_name = "a48009.jpg"
    img_path = os.path.join(os.getcwd() + "/IMGS/Test/inside_city/", img_name)
    img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
    plt.figure()
    plt.imshow(img, cmap="gray")
    img = cv2.resize(img, (IMAGE_SIZE_WEIGHT, IMAGE_SIZE_HEIGHT))
    return img


def show_image(img):
    plt.figure()
    plt.imshow(img, cmap="gray")
    plt.show()


def create_test_data(img, test_data):
    test_data.append(img)
    test_data2 = np.array(test_data)
    print(test_data2.shape)
    test_data = np.array(test_data).reshape(-1, IMAGE_SIZE_HEIGHT, IMAGE_SIZE_WEIGHT, 1)
    test_data = test_data/255.0
    print(" * Test_data: ", test_data)
    print(" * Test_data type: ", type(test_data))
    print(" * Test_data shape: ", test_data.shape)
    return test_data


def load_model():
    return tf.keras.models.load_model('cat_dog.model')


def predict(model, test_data, Categories):
    predictions = model.predict(test_data)
    print(" * Prediction:")
    for p in predictions[0]:
        print("- ", p)
    print(f'\n * Wynik: {Categories[np.argmax(predictions[0])]} ( {np.amax(predictions[0])} )')


if __name__ == "__main__":
    test_data = []
    Categories = [
        "coast",        # 0
        "forest",       # 1
        "highway",      # 2
        "inside_city",  # 3
        "mountain",     # 4
        "opencountry",  # 5
        "street",       # 6
        "tallbuilding"  # 7
    ]
    IMAGE_SIZE_HEIGHT = 250
    IMAGE_SIZE_WEIGHT = 250

    img = load_image()
    # show_image(img)
    test_data = create_test_data(img, test_data)
    model = load_model()
    predict(model, test_data, Categories)
