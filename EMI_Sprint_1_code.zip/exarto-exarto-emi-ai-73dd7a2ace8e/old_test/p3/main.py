import matplotlib.pyplot as plt
import tensorflow as tf
import numpy as np
import pickle
import random
import cv2
import os


def show_example_image():
    img_name = "art1130.jpg"
    img_path = os.path.join(os.getcwd() + "/IMGS/Train/coast/", img_name)
    img_array = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
    plt.figure()
    plt.imshow(img_array, cmap="gray")
    # Normalisation #
    new_array = cv2.resize(img_array, (IMAGE_SIZE_WEIGHT, IMAGE_SIZE_HEIGHT))
    plt.figure()
    plt.imshow(new_array, cmap="gray")
    plt.show()


def create_training_data(training_data, Categories):
    for category in Categories:
        path = os.path.join(os.getcwd() + "/IMGS/Train/", category)
        class_num = Categories.index(category)
        for img in os.listdir(path):
            try:
                img_array = cv2.imread(os.path.join(path, img), cv2.IMREAD_GRAYSCALE)
                array_normalised = cv2.resize(img_array, (IMAGE_SIZE_WEIGHT, IMAGE_SIZE_HEIGHT))
                training_data.append([array_normalised, class_num])
            except Exception as e:
                pass
                # print(" * Exeption show:", e)
    print(" * Traing data size: ", len(training_data))
    return training_data


def create_data_set(training_data, IMAGE_SIZE_HEIGHT, IMAGE_SIZE_WEIGHT):
    X, y = [], []
    for features, label in training_data:
        X.append(features)
        y.append(label)
    X = np.array(X).reshape(-1, IMAGE_SIZE_HEIGHT, IMAGE_SIZE_WEIGHT, 1)
    y = np.array(y)
    print(f' * X.shape = {X.shape},\n * y.shape = {y.shape}')
    return X, y


def save_data_as_serialization(X, y):
    pickle_out = open("X.pickle", "wb")
        pickle.dump(X, pickle_out)
    pickle_out.close()
    pickle_out = open("y.pickle", "wb")
    pickle.dump(y, pickle_out)
    pickle_out.close()


if __name__ == "__main__":
    print(" * Tensorflow version:", tf.__version__)

    Categories = ["coast",        # 0
                  "forest",       # 1
                  "highway",      # 2
                  "inside_city",  # 3
                  "mountain",     # 4
                  "opencountry",  # 5
                  "street",       # 6
                  "tallbuilding"  # 7
                  ]

    IMAGE_SIZE_HEIGHT = 250
    IMAGE_SIZE_WEIGHT = 250
    training_data = []

    show_example_image()
    training_data = create_training_data(training_data, Categories)
    random.shuffle(training_data)
    for i in training_data[:6]:
        print(" * ", i)
        print(80 * "-")
    X, y = create_data_set(training_data, IMAGE_SIZE_HEIGHT, IMAGE_SIZE_WEIGHT)
    save_data_as_serialization(X, y)