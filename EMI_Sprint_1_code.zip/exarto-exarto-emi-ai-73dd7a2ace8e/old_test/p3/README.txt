# link do obrazów:
	http://cvcl.mit.edu/database.htm
# p3 kożysta z wirtualnego środowiska p1 
