# link do obrazów CIFAR:
	https://www.cs.toronto.edu/~kriz/cifar.html
# p2 kożysta z wirtualnego środowiska p1 
