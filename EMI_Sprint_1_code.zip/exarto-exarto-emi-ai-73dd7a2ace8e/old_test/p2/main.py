import matplotlib.pyplot as plt
import tensorflow as tf
import numpy as np
import pickle
import random
import cv2
import os


def show_example_image():
    img_name = "8_ship.png"
    img_path = os.path.join(os.getcwd() + "/cifar/train/", img_name)
    img_array = cv2.imread(img_path) #, cv2.IMREAD_GRAYSCALE)
    plt.figure()
    plt.imshow(img_array) #, cmap="gray")
    # # Normalisation #
    # new_array = cv2.resize(img_array, (IMAGE_SIZE_WEIGHT, IMAGE_SIZE_HEIGHT))
    # plt.figure()
    # plt.imshow(new_array, cmap="gray")
    plt.show()


def create_training_data(training_data, Categories):
    for category in Categories:
        path = os.path.join(os.getcwd() + "/kagglecatsanddogs/PetImages", category)
        class_num = Categories.index(category)
        for img in os.listdir(path):
            try:
                img_array = cv2.imread(os.path.join(path, img), cv2.IMREAD_GRAYSCALE)
                array_normalised = cv2.resize(img_array, (IMAGE_SIZE_WEIGHT, IMAGE_SIZE_HEIGHT))
                training_data.append([array_normalised, class_num])
            except Exception as e:
                pass
                # print(" * Exeption show:", e)
    print(" * Traing data size: ", len(training_data))
    for i in training_data[:3]:
        print(" * ", i)
        print(80 * "-")
    return training_data


if __name__ == "__main__":

    Categories = [
        "airplane",
        "automobile",
        "bird",
        "cat",
        "deer",
        "dog",
        "frog",
        "horse",
        "ship",
        "truck"
    ]
    training_data = []
    IMAGE_SIZE_HEIGHT = 80
    IMAGE_SIZE_WEIGHT = 50
    show_example_image()
    create_training_data(training_data, Categories)
