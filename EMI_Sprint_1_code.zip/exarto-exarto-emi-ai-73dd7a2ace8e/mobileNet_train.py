from keras.applications.mobilenet import preprocess_input
from keras.preprocessing.image import ImageDataGenerator
from keras.layers import Dense, GlobalAveragePooling2D
from keras.applications import MobileNet
from keras.models import Model
from pprint import pprint
import getopt
import sys


def set_arguments(argv):
    model_name = 'landscapes_mobilenet.model'
    train_data_path = './train/'
    epochs = 5
    class_num = 8
    validation_split = 0.15
    image_width = 224
    image_height = 224
    try:
        opts, args = getopt.getopt(
            argv,
            "m:d:e:c:v:w:h:",
            [
                "model_name=",
                "directory_path=",
                "epochs=",
                "class=",
                "validation_split=",
                "width=",
                "height="
            ]
        )
    except getopt.GetoptError as err:
        print(err)
    for opt, arg in opts:
        if opt in ['-m', '--model_name']:
            model_name = arg
        if opt in ['-d', '--directory_path']:
            train_data_path = arg
        if opt in ['-e', '--epochs']:
            epochs = int(arg)
        if opt in ['-c', '--class']:
            class_num = int(arg)
        if opt in ['-v', '--validation_split']:
            validation_split = (int(arg)/100)
        if opt in ['-w', '--width']:
            image_width = int(arg)
        if opt in ['-h', '--height']:
            image_height = int(arg)
    print(f' * model name = {model_name},\n'
          f' * train data path = {train_data_path},\n'
          f' * epochs = {epochs},\n'
          f' * class number = {class_num},\n'
          f' * validation split = {validation_split},\n'
          f' * image width = {image_width},\n'
          f' * image_height = {image_height}'
    )
    parameters = {
        'model_name': model_name,
        'train_data_path': train_data_path,
        'epochs': epochs,
        'class_num': class_num,
        'validation_split': validation_split,
        'image_width': image_width,
        'image_height': image_height
    }
    return parameters


def create_model(class_num):
    base_model = MobileNet(
        weights='imagenet',
        include_top=False)
    x = base_model.output
    x = GlobalAveragePooling2D()(x)
    x = Dense(1024, activation='relu')(x)
    x = Dense(1024, activation='relu')(x)
    x = Dense(512, activation='relu')(x)
    preds = Dense(class_num, activation='softmax')(x)
    model = Model(
        inputs=base_model.input,
        outputs=preds)
    for i, layer in enumerate(model.layers):
        print(i, layer.name)
    return model


def configure_model_layers(model):
    for layer in model.layers[:20]:
        layer.trainable = False
    for layer in model.layers[20:]:
        layer.trainable = True
    # for ee, layer in enumerate(model.layers):
    #     print(ee, layer.trainable)
    return model


def plot_model(model):
    from keras.utils import plot_model
    plot_model(model, to_file='mobilenet_model.png')


def load_train_data(train_data_path, valid_split, img_width, img_height):
    train_datagen = ImageDataGenerator(
        preprocessing_function=preprocess_input,
        validation_split=valid_split
    )
    train_generator = train_datagen.flow_from_directory(
        train_data_path,
        target_size=(img_width, img_height),
        color_mode='rgb',
        batch_size=32,
        class_mode='categorical',
        shuffle=True,
        # validation_split=.2,
        # rescale=1. / 255,
        # shear_range=0.2,
        # zoom_range=0.2,
        # rotation_range=45,
        # horizontal_flip=True,
        # vertical_flip=True,
    )
    pprint(vars(train_generator))
    return train_generator


def compile_and_train(model, epochs):
    model.compile(
        optimizer='Adam',
        loss='categorical_crossentropy',
        metrics=['accuracy'])
    step_size_train = train_generator.n // train_generator.batch_size
    model.fit_generator(
        generator=train_generator,
        steps_per_epoch=step_size_train,
        epochs=epochs
    )
    return model


def save_model(model, model_name):
    model.save(model_name)


if __name__ == '__main__':
    parameters = set_arguments(sys.argv[1:])
    model = create_model(parameters['class_num'])
    model = configure_model_layers(model)
    train_generator = load_train_data(
        parameters['train_data_path'],
        parameters['validation_split'],
        parameters['image_width'],
        parameters['image_height']
    )
    model = compile_and_train(model, parameters['epochs'])
    save_model(model, parameters['model_name'])
    # plot_model(model)