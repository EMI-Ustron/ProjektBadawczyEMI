from keras.applications.mobilenet import preprocess_input
from keras.preprocessing.image import ImageDataGenerator
from keras.layers import Dense, GlobalAveragePooling2D
from keras.applications import MobileNet
from keras.models import Model
import matplotlib.pyplot as plt


def create_model():
    base_model = MobileNet(
        weights='imagenet',
        include_top=False)
    x = base_model.output
    x = GlobalAveragePooling2D()(x)
    x = Dense(1024, activation='relu')(x)
    x = Dense(1024, activation='relu')(x)
    x = Dense(512, activation='relu')(x)
    preds = Dense(2, activation='softmax')(x)   ##!
    model = Model(
        inputs=base_model.input,
        outputs=preds)
    for i, layer in enumerate(model.layers):    # print model layers
        print(i, layer.name)
    return model


def configure_model_layers(model):
    for layer in model.layers[:20]:
        layer.trainable = False
    for layer in model.layers[20:]:
        layer.trainable = True
    return model


def load_train_data(train_data_path):
    train_datagen = ImageDataGenerator(
        preprocessing_function=preprocess_input,
        validation_split=0.15
    )
    train_generator = train_datagen.flow_from_directory(
        train_data_path,
        target_size=(224, 224),
        color_mode='rgb',
        batch_size=32,
        class_mode='categorical',
        shuffle=True
    )
    return train_generator


def compile_and_train(model):
    model.compile(
        optimizer='Adam',
        loss='binary_crossentropy', ##!
        metrics=['accuracy'])
    step_size_train = train_generator.n // train_generator.batch_size
    history = model.fit_generator(
        generator=train_generator,
        steps_per_epoch=step_size_train,
        epochs=1)
    return model, history


def save_model(model, model_name):
    model.save(model_name)


if __name__ == '__main__':
    train_data_path = './train2/'
    model_name = 'cat_dog_test.model'
    model = create_model()
    model = configure_model_layers(model)
    train_generator = load_train_data(train_data_path)
    model, history = compile_and_train(model)
    save_model(model, model_name)