from keras.preprocessing.image import ImageDataGenerator
from keras.applications import mobilenet, resnet50
import matplotlib.pyplot as plt
from pprint import pprint
import tensorflow as tf
import numpy as np
import getopt
import sys
import cv2
import os


def set_arguments(argv):
    model_name = 'landscapes.model'
    image_path = './test/'
    functions = [
        resnet50.preprocess_input,
        mobilenet.preprocess_input
    ]
    preproces_function = functions[1]
    try:
        opts, args = getopt.getopt(argv, "m:d:", ["model_name=", "directory_path="])
    except getopt.GetoptError as err:
        print(err)
    for opt, arg in opts:
        if opt in ['-m', '--model_name']:
            model_name = arg
        if opt in ['-d', '--directory_path']:
            image_path = arg

    print(' * model_name: ', model_name)
    print(' * image_path: ', image_path)
    return model_name, image_path, preproces_function


def create_test_data(test_data_path, preproces_function):
    test_datagen = ImageDataGenerator(preprocessing_function=preproces_function)
    test_generator = test_datagen.flow_from_directory(
        test_data_path,
        target_size=(224, 224),
        color_mode='rgb',
        batch_size=1,
        class_mode='categorical',
        shuffle=False
    )
    pprint(vars(test_generator))
    return test_generator


def show_image(test_generator):
    x, y = test_generator.next()
    image = x[0]
    plt.imshow(image)
    plt.show()


def load_model(model_name):
    return tf.keras.models.load_model(model_name)


def predict(model, test_generator, Categories):
    nb_samples = len(test_generator.filenames)
    print(f' * samples number: {nb_samples}')
    print(f' * {test_generator.class_indices}\n')
    predict = model.predict_generator(test_generator, nb_samples, verbose=1)
    print(' --- Predictions: \n')
    for sample_number, sample in enumerate(predict):
        print(f' * Sample: {sample_number+1}')
        for neuron_exit, propability in enumerate(sample):
            print(f' --> {neuron_exit} :', propability)
        print(f' * Wynik: {Categories[np.argmax(sample)]}, Prawd:({np.amax(sample)}) ')
        print(f' * Orginal: ({Categories[test_generator.labels[sample_number]]})')
        print(50*"=")


if __name__ == "__main__":

    Categories = [
        "coast",        # 0
        "forest",       # 1
        "highway",      # 2
        "inside_city",  # 3
        "mountain",     # 4
        "opencountry",  # 5
        "street",       # 6
        "tallbuilding"  # 7
    ]
    # Categories = ["Cat", "Dog"]

    model_name, image_path, preproces_function = set_arguments(sys.argv[1:])
    test_generator = create_test_data(image_path, preproces_function)
    show_image(test_generator)
    model = load_model(model_name)
    predict(model, test_generator, Categories)
