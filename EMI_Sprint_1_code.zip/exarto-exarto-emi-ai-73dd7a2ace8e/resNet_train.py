from keras.layers import Dense, GlobalAveragePooling2D, Dropout
from keras.applications.resnet50 import preprocess_input
from keras.preprocessing.image import ImageDataGenerator
from keras import applications, Model
from keras import optimizers
from pprint import pprint
import getopt
import sys


def set_arguments(argv):
    model_name = 'landscapes_resnet.model'
    train_data_path = './train/'
    epochs = 5
    try:
        opts, args = getopt.getopt(argv, "m:d:e:", ["model_name=", "directory_path=", "epochs="])
    except getopt.GetoptError as err:
        print(err)
    for opt, arg in opts:
        if opt in ['-m', '--model_name']:
            model_name = arg
        if opt in ['-d', '--directory_path']:
            image_path = arg
        if opt in ['-e', '--epochs']:
            epochs = int(arg)

    print(' * model_name: ', model_name)
    print(' * image_path: ', image_path)
    print(' * epochs: ', epochs)
    return model_name, train_data_path, epochs


def create_model(number_of_classes, resnet_weights_path):
    base_model = applications.resnet50.ResNet50(
        weights=resnet_weights_path,
        # input_shape=(img_height, img_width, 3))
        include_top=False)
    x = base_model.output
    x = GlobalAveragePooling2D()(x)
    x = Dropout(0.7)(x)
    predictions = Dense(number_of_classes, activation='softmax')(x)
    model = Model(inputs=base_model.input, outputs=predictions)
    for i, layer in enumerate(model.layers):
        print(i, layer.name)
    return model


def configure_model_layers(model):
    for layer in model.layers[:25]:
        layer.trainable = False
    for layer in model.layers[25:]:
        layer.trainable = True
    for ee, layer in enumerate(model.layers):
        print(ee, layer.trainable)
    return model


def load_data(train_data_path, valid_data_path):
    data_generator = ImageDataGenerator(preprocessing_function=preprocess_input)
    train_generator = data_generator.flow_from_directory(
        train_data_path,
        target_size=(224, 224),
        color_mode='rgb',
        batch_size=32,
        class_mode='categorical'
    )
    validation_generator = data_generator.flow_from_directory(
        valid_data_path,
        target_size=(224, 224),
        color_mode='rgb',
        batch_size=32,
        class_mode='categorical'
    )
    pprint(vars(train_generator))
    return train_generator, validation_generator


def plot_model(model):
    from keras.utils import plot_model
    plot_model(model, to_file='resnet50_model.png')


def compile_and_train(model, train_generator, validation_generator, epochs):
    objective_function = 'categorical_crossentropy'
    loss_function = ['accuracy']
    sgd = optimizers.SGD(lr=0.01, decay=1e-6, momentum=0.9, nesterov=True)
    model.compile(optimizer=sgd, loss=objective_function, metrics=loss_function)
    step_size_train = train_generator.n // train_generator.batch_size
    validation_step = validation_generator.n // validation_generator.batch_size
    fit_history = model.fit_generator(
        train_generator,
        steps_per_epoch=step_size_train,
        epochs=epochs,
        validation_data=validation_generator,
        validation_steps=validation_step,  #10
    )
    return model, fit_history


def save_model(model, model_name):
    model.save(model_name)


if __name__ == '__main__':
    number_of_classes = 8
    valid_data_path = './valid/'
    resnet_weights_path = '/home/ubu/.keras/models/resnet50_weights_tf_dim_ordering_tf_kernels_notop.h5'

    model_name, train_data_path, epochs = set_arguments(sys.argv[1:])
    model = create_model(number_of_classes, resnet_weights_path)
    configure_model_layers(model)
    train_generator, validation_generator = load_data(train_data_path, valid_data_path)
    model, fit_history = compile_and_train(model, train_generator, validation_generator, epochs)
    save_model(model, model_name)
    # plot_model(model)