from keras.applications.mobilenet import preprocess_input
from keras.preprocessing.image import ImageDataGenerator
from keras.layers import Dense, GlobalAveragePooling2D
from keras.applications import MobileNet
from keras.models import Model
from pprint import pprint


def load_train_data(train_data_path):
    train_datagen = ImageDataGenerator(
        rescale=1. / 255,
        shear_range=0.2,
        zoom_range=0.2,
        rotation_range=45,
        horizontal_flip=True,
        vertical_flip=True,
        validation_split=.2
    )
    test_datagen = ImageDataGenerator(
        rescale=1. / 255,
        validation_split=.2
    )
    training_set = train_datagen.flow_from_directory(
        train_data_path,
        target_size=(224, 224),
        color_mode='rgb',
        batch_size=32,
        class_mode='categorical',
        subset='training')

    validation_set = test_datagen.flow_from_directory(
        train_data_path,
        target_size=(224, 224),
        color_mode='rgb',
        batch_size=32,
        class_mode='categorical',
        shuffle=False,
        subset='validation')
    pprint(f' * training_set: {vars(training_set)} \n')
    pprint(f' * validation_set: {vars(validation_set)}')
    return training_set, validation_set


def create_model():
    base_model = MobileNet(
        weights='imagenet',     # download weights/parameters from repository
        include_top=False       # remove last layer
    )

    x = base_model.output
    x = GlobalAveragePooling2D()(x)
    x = Dense(1024, activation='relu')(x)
    x = Dense(1024, activation='relu')(x)
    x = Dense(512, activation='relu')(x)
    preds = Dense(8, activation='softmax')(x)
    model = Model(
        inputs=base_model.input,
        outputs=preds
    )
    for layer_number, layer in enumerate(model.layers):
        print(layer_number, layer.name)
    return model


def configure_model_layers(model):
    for layer in model.layers[:20]:
        layer.trainable = False
    for layer in model.layers[20:]:
        layer.trainable = True
    return model


def compile_and_train(model, training_set, validation_set):
    model.compile(
        optimizer='Adam',
        loss='categorical_crossentropy',
        metrics=['accuracy'])
    model.fit_generator(training_set,
                        steps_per_epoch=len(training_set),
                        epochs=5,
                        validation_data=validation_set,
                        validation_steps=len(validation_set))
    return model


def save_model(model, model_name):
    model.save(model_name)


if __name__ == '__main__':
    train_data_path = './train/'
    model_name = 'p4_test.model'
    training_set, validation_set = load_train_data(train_data_path)
    model = create_model()
    model = configure_model_layers(model)
    model = compile_and_train(model, training_set, validation_set)
    save_model(model, model_name)