from keras.applications import mobilenet, resnet50
from keras.preprocessing import image
import matplotlib.pyplot as plt
import tensorflow as tf
import numpy as np
import getopt
import sys


def set_parameters(argv):
    model_name = 'landscapes.model'
    image_path = './test/street/a205062.jpg'
    functions = [
        resnet50.preprocess_input,
        mobilenet.preprocess_input
    ]
    preproces_function = functions[1]
    try:
        opts, args = getopt.getopt(argv, "m:i:", ["model_name=", "image_path="])
    except getopt.GetoptError as err:
        print(err)
    for opt, arg in opts:
        if opt in ['-m', '--model_name']:
            model_name = arg
        if opt in ['-i', '--image_path']:
            image_path = arg

    print(' * model_name: ', model_name)
    print(' * image_path: ', image_path)
    return model_name, image_path, preproces_function


def load_image(image_path):
    return image.load_img(image_path, target_size=(224, 224))


def show_image(img):
    plt.imshow(img, cmap="gray")
    plt.show()


def create_test_data(image_path, preproces_function):
    img = image.load_img(image_path, target_size=(224, 224))
    x = image.img_to_array(img)
    x = np.expand_dims(x, axis=0)
    test_data = preproces_function(x)
    return test_data


def load_model(model_name):
    return tf.keras.models.load_model(model_name)


def predict(model, test_data):
    predictions = model.predict(test_data)
    print(" * Prediction:")
    for p in predictions[0]:
        print("- ", p)
    print(f'\n * Wynik: {Categories[np.argmax(predictions[0])]}, {np.amax(predictions[0])} \n')


if __name__ == "__main__":
    model_name, image_path, preproces_function = set_parameters(sys.argv[1:])

    Categories = [
        "coast",        # 0
        "forest",       # 1
        "highway",      # 2
        "inside_city",  # 3
        "mountain",     # 4
        "opencountry",  # 5
        "street",       # 6
        "tallbuilding"  # 7
    ]

    img = load_image(image_path)
    show_image(img)
    model = load_model(model_name)
    test_data = create_test_data(image_path, preproces_function)
    predict(model, test_data)
